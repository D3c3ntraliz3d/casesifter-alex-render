# CaseSifter tester pack (agents only)

Not the whole app — pipeline / detectors / validators + `.env.example`.

## Gemini

- Prefer `GEMINI_MODEL=gemini-3.6-flash` (override the `.env.example` default of `gemini-2.5-flash`).
- With `CONTEXTUAL_MULTIMODAL=true`, exhibits send original PDF/image as base64 `inline_data` plus text excerpt.
- Court filings skip native file upload; oversized / unsupported formats fall back to text-only.

## Layout

See `backend/app/pipeline.py` (orchestrator), `backend/app/engines/` (detectors), `backend/app/gotcha.py` + `llm_verify.py` (validators), `backend/app/practice_packs/`.

Put secrets only in a local `.env` — never commit keys.
